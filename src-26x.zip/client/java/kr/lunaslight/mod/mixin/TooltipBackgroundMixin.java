package kr.lunaslight.mod.mixin;

import kr.lunaslight.mod.gui.LunaTooltipFrame;
import kr.lunaslight.mod.util.LunaCompat;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.resources.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * 49-23차: 툴팁 꾸미기. 바닐라 툴팁 배경(TooltipBackgroundRenderer.render)을 취소하고 LunaTooltipFrame이
 * 등급 색 테두리 상자를 대신 그린다. render의 시그니처가 세 시대로 갈려서(1.20.1~1.21.1 z 포함 /
 * 1.21.2~1.21.5 z + 텍스처 / 1.21.6+ 텍스처만) 디스크립터별 핸들러 셋을 두고 require=0으로 맞는 것만 적용.
 * 아이템/리소스팩이 자체 툴팁 텍스처를 지정한 경우(texture != null)는 존중해서 손대지 않는다.
 * 49-36차: 클래스 리터럴 대신 이름 문자열(targets) - TooltipBackgroundRenderer가 없는 1.19.2 이하에서도 컴파일되게.
 */
@Mixin(targets = "net.minecraft.client.gui.screens.inventory.tooltip.TooltipRenderUtil")
public abstract class TooltipBackgroundMixin {



	@Inject(method = "extractTooltipBackground(Lnet/minecraft/client/gui/GuiGraphicsExtractor;IIIILnet/minecraft/resources/Identifier;)V", at = @At("HEAD"), cancellable = true, require = 0)
	private static void lunaslight$frameTex(GuiGraphicsExtractor ctx, int x, int y, int w, int h, Identifier texture, CallbackInfo ci) {
		// 49-538차(사용자: "뭔데 없애"): 49-532차 너굴마을 갈색 설명 상자(NeogulTooltipStyle)는 잘못 알아들어 넣은 것 - 쓰지 않는다.
		if (!LunaTooltipFrame.enabled || texture != null) {
			return;
		}
		if (LunaTooltipFrame.render(ctx, x, y, w, h)) {
			ci.cancel();
		}
	}
}
