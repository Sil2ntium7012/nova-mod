package kr.lunaslight.mod.util;

import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.Display;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.LightLayer;

/**
 * 49-406차(사용자: "인게임에서 서버 치장이 시야에 보인대, F5 안 하면 1인칭에선 보이면 안 되는데, 그리고 치장이 막 밝게 보여"):
 * 서버 치장(가방, 모자, 날개 등 - Nexo/ModelEngine/HMCCosmetics류가 서버 리소스팩 모델로 플레이어에 붙인 엔티티)은 따로 된 엔티티라
 * 1인칭에서도 그대로 그려져 눈앞을 가렸고, 서버가 밝기를 고정해 두면(brightness) 어두운 곳에서도 빛났다.
 * <ul>
 *   <li>1인칭(카메라 = 나)이면 내 치장은 안 그린다(EntityRenderer.shouldRender).</li>
 *   <li>플레이어 치장인 디스플레이의 밝기는 고정값 대신 그 플레이어 자리의 밝기(플레이어 몸과 같게, DisplayRenderer). 글자 디스플레이는 그대로.</li>
 * </ul>
 * 49-430차(사용자: "서버 리소스팩 치장이 1인칭에서 보이고 밝은 오류 여전"): 예전엔 플레이어에 "타 있는" 디스플레이만 봤다. 서버에 따라
 * 치장을 태우지 않고 매 틱 플레이어 자리로 옮기거나(따라다니기), 디스플레이 대신 투명 갑옷 거치대에 씌운다. 이제
 * <ul>
 *   <li>디스플레이, 투명하거나 마커인 갑옷 거치대만 본다(보이는 갑옷 거치대, 몹은 그대로).</li>
 *   <li>타 있으면 맨 아래 탈것인 플레이어, 안 타 있으면 몸 안에 들어와 있는(가로 0.8칸, 발 0.5칸 아래 ~ 머리 1칸 위) 플레이어의 치장으로 본다.</li>
 * </ul>
 */
public final class RiderCosmetics {
	private RiderCosmetics() {
	}

	private static boolean cosmeticKind(Entity e) {
		if (e instanceof Display) {
			return true;
		}
		return e instanceof ArmorStand a && (a.isInvisible() || a.isMarker());
	}

	/** 이 치장 엔티티의 주인 플레이어(없으면 null). */
	public static Player ownerOf(Entity e) {
		if (e == null || !cosmeticKind(e)) {
			return null;
		}
		Entity root = e.getRootVehicle();
		if (root != e) {
			return root instanceof Player p ? p : null;
		}
		// 49-754차(사용자: "양배추가 아직도 가까이 가면 안 보임"): 서버 가구/작물(Nexo 가구 = 제자리 표시 엔티티)에 다가서면
		// 0.8블록 안이라 내 치장으로 잘못 보고 1인칭에서 숨겼다. 타지 않은 것은 한 번이라도 움직인 것(플레이어를 따라다니는 것)만 치장으로 본다.
		if (!moved(e)) {
			return null;
		}
		Player best = null;
		double bestD = 0.64;
		for (Player p : e.level().players()) {
			if (p.isSpectator()) {
				continue;
			}
			double dx = e.getX() - p.getX();
			double dz = e.getZ() - p.getZ();
			double d = dx * dx + dz * dz;
			if (d > bestD) {
				continue;
			}
			double dy = e.getY() - p.getY();
			if (dy < -0.5 || dy > p.getBbHeight() + 1.0) {
				continue;
			}
			best = p;
			bestD = d;
		}
		return best;
	}

	/** 처음 본 자리와 움직였는지. 렌더 스레드에서만 쓴다. 엔티티가 사라지면 같이 지워진다. */
	private static final java.util.Map<Entity, double[]> FIRST = new java.util.WeakHashMap<>();

	private static boolean moved(Entity e) {
		double[] f = FIRST.get(e);
		if (f == null) {
			FIRST.put(e, new double[]{e.getX(), e.getY(), e.getZ(), 0});
			return false;
		}
		if (f[3] != 0) {
			return true;
		}
		double dx = e.getX() - f[0], dy = e.getY() - f[1], dz = e.getZ() - f[2];
		if (dx * dx + dy * dy + dz * dz > 1.0e-4) {
			f[3] = 1;
			return true;
		}
		return false;
	}

	/** 예전 이름(다른 곳에서 부를 수 있어 남김). */
	public static Player riderOf(Entity e) {
		return ownerOf(e);
	}

	/** 1인칭에서 내 몸의 치장인가. */
	public static boolean hideInFirstPerson(Entity e) {
		try {
			Minecraft mc = Minecraft.getInstance();
			if (mc == null || mc.player == null || mc.getCameraEntity() != mc.player
					|| !mc.options.getCameraType().isFirstPerson() || !cosmeticKind(e)) {
				return false;
			}
			if (ownerOf(e) != mc.player) {
				return false;
			}
			// 49-759차(사용자: "플레이어 치장도 보여야 한다고, 타인 것은"): 타지 않은 치장은 누구 것인지 자리로만 짐작한다.
			// 49-804차(사용자 사진: 잠광 자리에서 치장이 화면을 가림 - "치장은 아직도 이런데?"): 예전에는 다른 사람이 1.5칸 안에 있으면 무조건 안 숨겨서,
			// 여럿이 붙어 서는 잠광 자리에서는 내 치장이 계속 보였다. 이제 누구 것인지 확실할 때 주인을 기억해 두고(stickyOwner), 헷갈릴 때는 기억한 주인을 쓴다.
			if (e.getRootVehicle() == e) {
				return stickyOwner(e, mc.player) == mc.player;
			}
			return true;
		} catch (Throwable t) {
			return false;
		}
	}

	/** 타지 않은 치장 → 확실했을 때 정한 주인(엔티티 번호). 렌더 스레드에서만 쓴다. */
	private static final java.util.Map<Entity, Integer> OWNER = new java.util.WeakHashMap<>();

	/**
	 * 타지 않고 따라다니는 치장의 주인. 치장은 주인 자리에 그대로 겹쳐 있으므로(가로 거리 거의 0), 가장 가까운 플레이어가
	 * 둘째로 가까운 플레이어보다 뚜렷이 가깝거나(가로 0.14칸 안이고 둘째와 제곱 거리 차 0.05 넘음) 둘레 1.5칸에 그 사람뿐이면 확실한 것으로 보고 기억한다.
	 * 확실하지 않으면 기억해 둔 주인을, 기억도 없으면 null(숨기지 않음 - 남의 것을 숨기느니 내 것이 잠깐 보이는 쪽).
	 */
	private static Player stickyOwner(Entity e, Player me) {
		Player best = null;
		double bestD = Double.MAX_VALUE, secondD = Double.MAX_VALUE;
		Player remembered = null;
		Integer rid = OWNER.get(e);
		for (Player p : e.level().players()) {
			if (p.isSpectator()) {
				continue;
			}
			if (rid != null && p.getId() == rid) {
				remembered = p;
			}
			double dy = e.getY() - p.getY();
			if (dy < -1.0 || dy > p.getBbHeight() + 1.5) {
				continue;
			}
			double dx = e.getX() - p.getX();
			double dz = e.getZ() - p.getZ();
			double d = dx * dx + dz * dz;
			if (d < bestD) {
				secondD = bestD;
				bestD = d;
				best = p;
			} else if (d < secondD) {
				secondD = d;
			}
		}
		if (best != null && bestD <= 0.64) {
			boolean alone = secondD >= 2.25;
			boolean clear = bestD < 0.02 && secondD > bestD + 0.05;
			if (alone || clear) {
				OWNER.put(e, best.getId());
				return best;
			}
		}
		if (remembered != null) {
			double dx = e.getX() - remembered.getX(), dz = e.getZ() - remembered.getZ();
			if (dx * dx + dz * dz <= 2.25) {
				return remembered;   // 아직 그 사람 곁에 있다
			}
			OWNER.remove(e);
		}
		return null;
	}

	/** 플레이어 치장 디스플레이면 그 플레이어 자리의 밝기(-1 = 바닐라대로). 글자 디스플레이는 그대로(읽기 쉽게). */
	public static int light(Entity e, boolean sky) {
		try {
			if (e instanceof Display.TextDisplay) {
				return -1;
			}
			Player p = ownerOf(e);
			if (p == null) {
				return -1;
			}
			if (!sky && p.isOnFire()) {
				return 15;
			}
			BlockPos pos = BlockPos.containing(p.getEyePosition());
			return e.level().getBrightness(sky ? LightLayer.SKY : LightLayer.BLOCK, pos);
		} catch (Throwable t) {
			return -1;
		}
	}
}
