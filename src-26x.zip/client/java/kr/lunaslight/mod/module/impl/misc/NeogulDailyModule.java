package kr.lunaslight.mod.module.impl.misc;

import kr.lunaslight.mod.module.Module;
import kr.lunaslight.mod.module.ModuleCategory;
import kr.lunaslight.mod.module.setting.ActionSetting;
import kr.lunaslight.mod.module.setting.BooleanSetting;
import kr.lunaslight.mod.module.setting.ColorSetting;
import kr.lunaslight.mod.module.setting.HudPosition;
import kr.lunaslight.mod.module.setting.PositionSetting;
import kr.lunaslight.mod.module.setting.StringSetting;
import kr.lunaslight.mod.util.ChatState;
import kr.lunaslight.mod.util.NeogulData;
import kr.lunaslight.mod.util.LunaCompat;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.DeltaTracker;

import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Locale;

/**
 * 49-133차(사용자: "너굴 추천 및 핫타임 - 너굴마을 추천하면 체크 표시가 뜨는 UI + 핫타임까지 남은 시간과 받았다는 표시",
 * 감지 = 서버 채팅 메시지): <b>너굴 추천 핫타임</b> HUD. 49-134차: 핫타임은 위키 기준 매일 저녁 8시(20시).
 *
 * <pre>
 *  추천    [v]
 *  핫타임  [ ] 02:13:05
 * </pre>
 * 추천/핫타임 보상 메시지가 채팅에 오면({@link ChatState#addPlainListener}) 그날 칸에 체크가 들어가고, 자정에 풀린다.
 * 감지 낱말은 아래 REC_WORDS / HOT_WORDS(코드)에서 고친다. 잘못 잡히면 [체크 바꾸기]로 직접 고친다.
 * 핫타임 시각이 되면 알림음 한 번.
 */
public class NeogulDailyModule extends Module {

	private final PositionSetting position = register(new PositionSetting(
			"position", "위치", "표시 위치입니다.", HudPosition.of(HudPosition.Anchor.TOP_LEFT, 4, 130)));

	private final ColorSetting textColor = register(new ColorSetting(
			"text_color", "글자 색", "글자의 색입니다.", 0xFFFFFFFF));

	// 49-167차(사용자: "핫타임 시간은 고정, 너굴마을에서만 설정은 없애, 앞의 에메랄드/시계 없애"): 핫타임 20시 고정(위키),
	// 너굴마을(mcng.kr) 접속 중에만 보임 - 서버 기능이라 설정으로 두지 않는다. 아이템 아이콘 없이 글자와 체크 칸만.
	private static final int HOT_HOUR = 20;

	private final BooleanSetting alarm = register(new BooleanSetting(
			"alarm", "핫타임 알림음", "핫타임 시각이 되면 소리를 한 번 냅니다(아직 안 받았을 때만).", true));

	// 49-143차(사용자: "핫타임/추천 감지 글은 내가 설정할 거야 개인 설정 없애"): 감지 낱말은 설정이 아니라 여기서 고친다.
	// 채팅 한 줄에서 띄어쓰기를 빼고 이 낱말(띄어쓰기 빼고)이 들어 있으면 체크된다.
	/** 추천 완료로 보는 채팅 낱말. */
	// 49-502차(사용자: "추천 안 했는데 완료라 뜨잖아"): "추천 감사", "추천해 주셔서"는 다른 사람 추천 알림이나 플레이어 채팅("추천 감사해요")에도
	// 들어 있어서 남이 추천해도 체크됐다. 이제 서버 알림 "<내 이름>님이 오늘 N번째로 서버를 추천해주셨습니다"와 나에게 오는 "추천 보상"만.
	private static final List<String> REC_WORDS = List.of("추천 보상");
	/** 플레이어 채팅 줄("(64명) 이름: 글", "[질문] 이름: 글") - 이런 줄은 감지에서 뺀다. */
	private static final java.util.regex.Pattern PLAYER_CHAT = java.util.regex.Pattern.compile("[A-Za-z0-9_]{3,16}\\s*:\\s");
	/** 핫타임 받음으로 보는 채팅 낱말. */
	private static final List<String> HOT_WORDS = List.of("핫타임 보상", "핫타임 지급");
	/** 핫타임 시각부터 이 분 동안은 "지금"(받을 수 있는 때). 그 뒤에도 못 받았으면 그날은 X. */
	private static final int HOT_WINDOW_MIN = 10;

	/** 저장용: 날짜|추천|핫타임|알림 울림. */
	private final StringSetting state = register(new StringSetting("state", "상태", "", ""));

	public NeogulDailyModule() {
		super("neogul_daily", "너굴 추천 핫타임", ModuleCategory.SERVER, "추천 체크 | 핫타임까지 남은 시간");
		serverGroup("너굴마을");
		state.hidden();
		register(new ActionSetting("toggle_rec", "추천 체크", "오늘 추천 체크를 직접 켜거나 끕니다.", "체크 전환",
				() -> set(1, !flag(1))));
		register(new ActionSetting("toggle_hot", "핫타임 체크", "오늘 핫타임 받음 체크를 직접 켜거나 끕니다.", "체크 전환",
				() -> set(2, !flag(2))));
		ChatState.addPlainListener(this::onChat);
	}

	// ==================== 상태 ====================

	private String[] parts() {
		String today = LocalDate.now().toString();
		String v = state.get();
		String[] p = v == null ? new String[0] : v.split("\\|");
		if (p.length < 4 || !today.equals(p[0])) {
			p = new String[]{today, "0", "0", "0"};
			state.setValue(String.join("|", p));
		}
		return p;
	}

	private boolean flag(int i) {
		return "1".equals(parts()[i]);
	}

	private void set(int i, boolean on) {
		String[] p = parts();
		String nv = on ? "1" : "0";
		if (!nv.equals(p[i])) {
			p[i] = nv;
			state.setValue(String.join("|", p));
		}
	}

	private boolean here() {
		return NeogulData.onNeogul(client);
	}

	private void onChat(String line) {
		if (!isEnabled() || line == null || line.isEmpty() || !here()) {
			return;
		}
		if (line.startsWith("<")) {
			return;   // 바닐라 형식 플레이어 채팅
		}
		String l = line.replace(" ", "");
		boolean playerChat = PLAYER_CHAT.matcher(line).find();
		String me = client.player == null ? "" : client.player.getName().getString();
		boolean mine = !me.isEmpty() && l.contains(me + "님이") && l.contains("서버를추천");
		boolean other = !mine && l.contains("님이") && l.contains("서버를추천");
		if (!flag(1) && (mine || (!playerChat && !other && matches(l, REC_WORDS)))) {
			set(1, true);
			LunaCompat.playUiSound(client, "BLOCK_NOTE_BLOCK_CHIME", 1.4f);
		}
		if (!flag(2) && !playerChat && matches(l, HOT_WORDS)) {
			set(2, true);
			LunaCompat.playUiSound(client, "BLOCK_NOTE_BLOCK_CHIME", 1.6f);
		}
	}

	private static boolean matches(String compact, List<String> words) {
		for (String w : words) {
			String c = w.replace(" ", "");
			if (!c.isEmpty() && compact.contains(c)) {
				return true;
			}
		}
		return false;
	}

	@Override
	public void onTick() {
		if (client == null || client.player == null || !here()) {
			return;
		}
		LocalDateTime now = LocalDateTime.now();
		if (alarm.get() && now.getHour() >= HOT_HOUR && !flag(2) && !flag(3)) {
			set(3, true);
			LunaCompat.playUiSound(client, "BLOCK_NOTE_BLOCK_BELL", 1.2f);
		}
	}

	/** 오늘 핫타임을 놓쳤는지(시각 + 10분이 지났는데 못 받음). 자정에 풀린다. */
	private boolean missed(boolean received) {
		return !received && !LocalDateTime.now().isBefore(LocalDate.now().atTime(HOT_HOUR, 0).plusMinutes(HOT_WINDOW_MIN));
	}

	/**
	 * 핫타임 칸 오른쪽 글자: 남은 시간, 시작하고 10분 동안 아직 안 받았으면 "지금".
	 * 49-143차(사용자: "그날에 못받으면 그날동안 X, 하루 지나면 없어지면서 시간으로"): 놓치면 글자 없이 X만.
	 */
	private String hotText(boolean received) {
		LocalDateTime now = LocalDateTime.now();
		LocalDateTime today = LocalDate.now().atTime(HOT_HOUR, 0);
		boolean passed = !now.isBefore(today);
		if (missed(received)) {
			return "";
		}
		if (!received && passed) {
			return "지금";
		}
		LocalDateTime target = received || passed ? today.plusDays(1) : today;
		long s = Math.max(0, Duration.between(now, target).getSeconds());
		return String.format(Locale.ROOT, "%02d:%02d:%02d", s / 3600, (s / 60) % 60, s % 60);
	}

	// ==================== 그리기 ====================

	// 49-443차(사용자: "너굴마을 추천이랑 핫타임 예쁘게좀 해주고"): 체크 칸 두 줄 → 카드 두 줄.
	//  ● 추천      [완료] / [아직]
	//  ● 핫타임    02:13:05 / [지금] (깜빡) / [받음] / [놓침]
	//  ─────────── (핫타임까지 남은 하루 진행 막대)
	// 왼쪽 점 = 상태 색, 오른쪽 = 알약. 배경은 이 기능의 [배경] 설정(HUD 배경) 그대로.

	private static final int OK = 0xFF4CC38A;
	private static final int WAIT = 0xFF8A919C;
	private static final int NOW = 0xFFFFC857;
	private static final int MISS = 0xFFFF6B6B;

	@Override
	public void onHudRender(GuiGraphicsExtractor ctx, DeltaTracker tickCounter) {
		if (!isPreview() && (client.player == null || !here())) {
			return;
		}
		boolean rec = isPreview() || flag(1);
		boolean hot = !isPreview() && flag(2);
		boolean miss = !isPreview() && missed(hot);
		String time = isPreview() ? "02:13:05" : hotText(hot);
		boolean now = "지금".equals(time);

		String recLabel = "추천";
		String hotLabel = "핫타임";
		String recPill = rec ? "완료" : "아직";
		int recCol = rec ? OK : WAIT;
		String hotPill;
		int hotCol;
		if (hot) {
			hotPill = "받음";
			hotCol = OK;
		} else if (miss) {
			hotPill = "놓침";
			hotCol = MISS;
		} else if (now) {
			hotPill = "지금";
			hotCol = NOW;
		} else {
			hotPill = null;   // 남은 시간 글자
			hotCol = WAIT;
		}
		int labelW = Math.max(LunaCompat.getTextWidth(client.font, recLabel), LunaCompat.getTextWidth(client.font, hotLabel));
		int pillW = Math.max(pillWidth(recPill), hotPill != null ? pillWidth(hotPill) : LunaCompat.getTextWidth(client.font, time));
		int w = Math.max(96, 6 + 8 + labelW + 12 + pillW + 6);
		boolean bar = hotPill == null;
		int h = 6 + 14 + 3 + 14 + (bar ? 7 : 4);
		int sw = client.getWindow().getGuiScaledWidth();
		int sh = client.getWindow().getGuiScaledHeight();
		int x = position.get().resolveX(sw, w);
		int y = position.get().resolveY(sh, h);
		drawHudPanel(ctx, x, y, w, h);
		// 49-474차(사용자: "좌우대칭이 달라지는 기능"): 화면 오른쪽 절반이면 점과 이름은 오른쪽, 알약/남은 시간은 왼쪽
		boolean right = hudOnRight(x, w);

		int color = textColor.getArgb();
		int r1 = y + 5;
		row(ctx, x, r1, w, recLabel, recCol, color, right);
		pill(ctx, right ? x + 6 : x + w - 6 - pillWidth(recPill), r1, recPill, recCol, false);

		int r2 = r1 + 17;
		row(ctx, x, r2, w, hotLabel, hotCol == WAIT ? 0xFF6EA8FF : hotCol, color, right);
		if (hotPill != null) {
			boolean blink = now && (System.currentTimeMillis() / 500) % 2 == 0;
			pill(ctx, right ? x + 6 : x + w - 6 - pillWidth(hotPill), r2, hotPill, hotCol, blink);
		} else {
			int tw = LunaCompat.getTextWidth(client.font, time);
			LunaCompat.drawHudText(ctx, client.font, time, right ? x + 6 : x + w - 6 - tw, r2 + 3, color);
		}
		if (bar) {
			// 핫타임까지 하루 중 얼마나 왔나(지난 20시 → 다음 20시). 오른쪽이면 오른쪽에서 차오름
			float f = isPreview() ? 0.9f : dayProgress();
			int bx = x + 6;
			int bw = w - 12;
			int by = y + h - 5;
			int fw = Math.max(2, Math.round(bw * f));
			kr.lunaslight.mod.gui.LunaDraw.roundRect(ctx, bx, by, bw, 2, 1, 0x30FFFFFF);
			kr.lunaslight.mod.gui.LunaDraw.roundRect(ctx, right ? bx + bw - fw : bx, by, fw, 2, 1, 0xE06EA8FF);
		}
	}

	/** 상태 점 + 이름(오른쪽이면 오른쪽 끝에서). */
	private void row(GuiGraphicsExtractor ctx, int x, int y, int w, String label, int dot, int color, boolean right) {
		if (right) {
			kr.lunaslight.mod.gui.LunaDraw.roundRect(ctx, x + w - 11, y + 4, 5, 5, 2, dot);
			LunaCompat.drawHudText(ctx, client.font, label, x + w - 15 - LunaCompat.getTextWidth(client.font, label), y + 3, color);
			return;
		}
		row(ctx, x, y, w, label, dot, color);
	}

	/** 왼쪽 상태 점 + 이름. */
	private void row(GuiGraphicsExtractor ctx, int x, int y, int w, String label, int dot, int color) {
		kr.lunaslight.mod.gui.LunaDraw.roundRect(ctx, x + 6, y + 4, 5, 5, 2, dot);
		LunaCompat.drawHudText(ctx, client.font, label, x + 15, y + 3, color);
	}

	private int pillWidth(String s) {
		return LunaCompat.getTextWidth(client.font, s) + 10;
	}

	/** 둥근 알약(옅은 같은 색 바탕 + 같은 색 글자). glow면 진하게(지금 받을 때 깜빡). */
	private void pill(GuiGraphicsExtractor ctx, int x, int y, String s, int col, boolean glow) {
		int w = pillWidth(s);
		int bg = (col & 0x00FFFFFF) | (glow ? 0xC0000000 : 0x38000000);
		kr.lunaslight.mod.gui.LunaDraw.roundRect(ctx, x, y, w, 13, 6, bg);
		LunaCompat.drawHudText(ctx, client.font, s, x + 5, y + 3, glow ? 0xFF1A1A1A : col);
	}

	/** 지난 핫타임(20시)부터 다음 핫타임까지 지난 비율. */
	private static float dayProgress() {
		LocalDateTime now = LocalDateTime.now();
		LocalDateTime next = LocalDate.now().atTime(HOT_HOUR, 0);
		if (!now.isBefore(next)) {
			next = next.plusDays(1);
		}
		long left = Duration.between(now, next).getSeconds();
		return Math.max(0f, Math.min(1f, 1f - left / 86400f));
	}

	/** 놓친 날: 같은 칸에 빨간 X. */
	private static void crossbox(GuiGraphicsExtractor ctx, int x, int y) {
		ctx.fill(x, y, x + 9, y + 9, 0xFF8B8B8B);
		ctx.fill(x + 1, y + 1, x + 8, y + 8, 0xFF1E1E1E);
		for (int i = 0; i < 5; i++) {
			ctx.fill(x + 2 + i, y + 2 + i, x + 3 + i, y + 3 + i, 0xFFFF5555);
			ctx.fill(x + 6 - i, y + 2 + i, x + 7 - i, y + 3 + i, 0xFFFF5555);
		}
	}

	/** 바닐라 느낌 체크 칸(9×9): 회색 테두리 + 어두운 속 + 초록 체크. */
	private static void checkbox(GuiGraphicsExtractor ctx, int x, int y, boolean on) {
		ctx.fill(x, y, x + 9, y + 9, 0xFF8B8B8B);
		ctx.fill(x + 1, y + 1, x + 8, y + 8, 0xFF1E1E1E);
		if (!on) {
			return;
		}
		int c = 0xFF55FF55;
		// ✔ 모양: 왼쪽 짧은 획 + 오른쪽 긴 획, 2px 굵기
		int[][] px = {{1, 4}, {2, 5}, {3, 6}, {4, 5}, {5, 4}, {6, 3}, {7, 2}};
		for (int[] p : px) {
			ctx.fill(x + p[0], y + p[1], x + p[0] + 1, y + p[1] + 2, c);
		}
	}
}
